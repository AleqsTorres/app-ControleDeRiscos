package com.example.projint_3

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

class TelaPrincipal : AppCompatActivity() {
    private lateinit var descricaoEditText: EditText
    private lateinit var nomecompletoEditText: EditText
    private lateinit var setorEditText: EditText
    private lateinit var adclocButton: Button
    private lateinit var adcimgButton: Button
    private lateinit var enviarButton: Button
    private lateinit var imageView: ImageView

    // Variáveis para localização
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private var currentLocation: Location? = null

    private val REQUEST_CODE_PICK_IMAGE = 100
    private val REQUEST_CODE_PERMISSIONS = 101
    private val REQUEST_CODE_LOCATION_PERMISSION = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tela_principal)

        // Inicializa o cliente de localização
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        descricaoEditText = findViewById(R.id.descricao)
        nomecompletoEditText = findViewById(R.id.nome_completo)
        setorEditText = findViewById(R.id.setor)
        enviarButton = findViewById(R.id.button)
        adcimgButton = findViewById(R.id.adcimgButton)
        adclocButton = findViewById(R.id.button2) // Botão de adicionar localização
        imageView = findViewById(R.id.imageView)

        adcimgButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_MEDIA_IMAGES), REQUEST_CODE_PERMISSIONS)
            } else {
                openImagePicker()
            }
        }

        adclocButton.setOnClickListener {
            checkLocationPermissionAndGetLocation()
        }

        enviarButton.setOnClickListener {
            val descricao = descricaoEditText.text.toString()
            val nomeCompleto = nomecompletoEditText.text.toString()
            val setor = setorEditText.text.toString()

            // Aqui você pode usar a currentLocation para obter as coordenadas
            currentLocation?.let { location ->
                val latitude = location.latitude
                val longitude = location.longitude
                // Adicione essas coordenadas ao seu objeto de envio
                Toast.makeText(this, "Localização: $latitude, $longitude", Toast.LENGTH_LONG).show()
            } ?: run {
                Toast.makeText(this, "Nenhuma localização foi adicionada", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun checkLocationPermissionAndGetLocation() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Solicita permissão se não tiver
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                REQUEST_CODE_LOCATION_PERMISSION
            )
        } else {
            // Se a permissão já foi concedida, obtém a localização
            getCurrentLocation()
        }
    }

    private fun getCurrentLocation() {
        // Verifica novamente a permissão por segurança
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val locationRequest = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            10000
        ).build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                super.onLocationResult(locationResult)
                currentLocation = locationResult.lastLocation
                Toast.makeText(
                    this@TelaPrincipal,
                    "Localização obtida: ${currentLocation?.latitude}, ${currentLocation?.longitude}",
                    Toast.LENGTH_LONG
                ).show()

                // Para de receber atualizações após obter a primeira localização
                fusedLocationClient.removeLocationUpdates(locationCallback)
            }
        }

        fusedLocationClient.requestLocationUpdates(
            locationRequest,
            locationCallback,
            Looper.getMainLooper()
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_CODE_PERMISSIONS -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openImagePicker()
                } else {
                    Toast.makeText(this, "Permissão negada para acessar a galeria", Toast.LENGTH_SHORT).show()
                }
            }
            REQUEST_CODE_LOCATION_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getCurrentLocation()
                } else {
                    Toast.makeText(this, "Permissão negada para acessar a localização", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_CODE_PICK_IMAGE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_PICK_IMAGE && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                imageView.setImageURI(uri)
            }
        }
    }
}